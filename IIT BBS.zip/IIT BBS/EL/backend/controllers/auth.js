const Student = require("../models/student");
const Faculty = require("../models/faculty");

exports.registerStudent = async (req, res) => {
    try {
        const student = await Student.create(req.body);
        res.status(201).json(student);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Handle Faculty Login
exports.loginFaculty = async (req, res) => {
    const { username, password } = req.body;

    try {
        const faculty = await Faculty.findOne({ username });

        if (!faculty) {
            return res.status(404).send("❌ Faculty not found");
        }

        if (faculty.password === password) {
            return res.status(200).send("✅ Login successful");
        } else {
            return res.status(401).send("❌ Incorrect password");
        }

    } catch (error) {
        console.error("Login error:", error);
        return res.status(500).send("❌ Server error");
    }
};