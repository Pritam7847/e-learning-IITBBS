function manageCourses() {
    alert("Redirecting to Course Management...");
    window.location.href = "#";
}

function manageAssignments() {
    alert("Redirecting to Assignment Management...");
    window.location.href = "#";
}

function trackPerformance() {
    alert("Redirecting to Student Performance Tracking...");
    window.location.href = "#";
}

function sendNotifications() {
    alert("Redirecting to Notifications...");
    window.location.href = "#";
}